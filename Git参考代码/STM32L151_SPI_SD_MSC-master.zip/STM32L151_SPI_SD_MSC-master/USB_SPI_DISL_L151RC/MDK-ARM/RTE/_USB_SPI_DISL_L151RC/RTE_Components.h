
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'USB_SPI_DISL_L151RC' 
 * Target:  'USB_SPI_DISL_L151RC' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32l1xx.h"



#endif /* RTE_COMPONENTS_H */
